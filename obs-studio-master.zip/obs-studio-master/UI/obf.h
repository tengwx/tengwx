#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

extern void deobfuscate_str(char *str, uint64_t val);

#ifdef __cplusplus
}
#endif
