#pragma once

#include <QCheckBox>

class ExpandCheckBox : public QCheckBox {
	Q_OBJECT
};
